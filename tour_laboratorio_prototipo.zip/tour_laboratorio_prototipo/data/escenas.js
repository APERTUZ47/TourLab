// Configuración editable del tour virtual.
// Para ajustar el recorrido, cambia nombres, tiempos, textos o archivos desde aquí.

window.TOUR_SCENES = {
  startScene: "pasillo",
  videosPath: "assets/videos/",
  scenes: {
    pasillo: {
      label: "Pasillo principal",
      instruction: "Scroll abajo para avanzar. Scroll arriba para retroceder. En los puntos activos puedes entrar o seguir de largo.",
      video: "01_pasillo_principal_web.mp4",
      scrollSensitivity: 0.018,
      startAt: 0,
      endAt: 40.1,
      hotspots: [
        {
          id: "entrar-salon-1",
          time: 13,
          window: 1.8,
          title: "Espacio 1: proyectos realizados",
          text: "Puedes entrar al primer salón o continuar por el pasillo.",
          actions: [
            { label: "Entrar al salón 1", type: "scene", target: "espacio1" },
            { label: "Seguir", type: "jump", time: 15.2, secondary: true }
          ]
        },
        {
          id: "entrar-salon-2",
          time: 19,
          window: 1.8,
          title: "Espacio 2: opiniones / segundo salón",
          text: "Aquí puede abrirse el segundo recorrido opcional.",
          actions: [
            { label: "Entrar al salón 2", type: "scene", target: "espacio2" },
            { label: "Seguir", type: "jump", time: 21.2, secondary: true }
          ]
        },
        {
          id: "listo-lab",
          time: 27,
          window: 1.7,
          title: "¿Listo para entrar al laboratorio?",
          text: "Puedes avanzar hacia la parte final del recorrido.",
          actions: [
            { label: "Claro", type: "jump", time: 29.5 },
            { label: "Por supuesto", type: "jump", time: 29.5, secondary: true }
          ]
        },
        {
          id: "transmedia-ia",
          time: 30,
          window: 1.7,
          title: "Estación 1: Transmedia e IA",
          text: "Hotspot reservado para el video o material de Transmedia e Inteligencia Artificial.",
          actions: [
            { label: "Ver estación", type: "message", message: "Aquí conectaremos el video de Transmedia e IA cuando lo tengas." },
            { label: "Seguir", type: "jump", time: 32.1, secondary: true }
          ]
        },
        {
          id: "podcast-sonido",
          time: 34,
          window: 1.8,
          title: "Estación 2: Podcast y sonido",
          text: "Abre el video de podcast/sonido que ya está contemplado en el proyecto.",
          actions: [
            { label: "Ver podcast", type: "modalVideo", video: "04_podcast_sonido_web.mp4", title: "Podcast y sonido" },
            { label: "Seguir", type: "jump", time: 36.1, secondary: true }
          ]
        },
        {
          id: "video-cierre",
          time: 37.5,
          window: 1.8,
          title: "Estación 3: Video y cierre",
          text: "Última zona del laboratorio. Puedes cerrar la experiencia o volver al inicio.",
          actions: [
            { label: "Finalizar", type: "end" },
            { label: "Volver al inicio", type: "home", secondary: true }
          ]
        }
      ]
    },

    espacio1: {
      label: "Espacio 1 / Salón 1",
      instruction: "Scroll dentro del salón. Al final aparecen elementos clickeables y el botón para volver al pasillo.",
      video: "02_espacio_1_salon1_web.mp4",
      scrollSensitivity: 0.02,
      startAt: 0,
      endAt: 25.9,
      returnScene: "pasillo",
      returnTime: 13.4,
      hotspots: [
        {
          id: "zona-clickeable-salon1",
          time: 20,
          window: 4,
          title: "Zona clickeable del salón 1",
          text: "Aquí se puede conectar un video específico del primer espacio.",
          actions: [
            { label: "Video pendiente", type: "message", message: "Cuando tengas el video clickeable del salón 1, ponlo en assets/videos y cambia esta acción en data/escenas.js." },
            { label: "Volver al pasillo", type: "return", secondary: true }
          ]
        }
      ]
    },

    espacio2: {
      label: "Espacio 2 / Salón 2",
      instruction: "Scroll dentro del segundo salón. Puedes abrir el video de podcast o volver al pasillo.",
      video: "03_espacio_2_salon_web.mp4",
      scrollSensitivity: 0.016,
      startAt: 0,
      endAt: 46.1,
      returnScene: "pasillo",
      returnTime: 19.4,
      hotspots: [
        {
          id: "zona-clickeable-salon2",
          time: 36,
          window: 6,
          title: "Zona clickeable del salón 2",
          text: "Desde aquí puedes abrir el material de podcast/sonido o regresar al pasillo.",
          actions: [
            { label: "Ver podcast", type: "modalVideo", video: "04_podcast_sonido_web.mp4", title: "Podcast y sonido" },
            { label: "Volver al pasillo", type: "return", secondary: true }
          ]
        }
      ]
    }
  }
};
