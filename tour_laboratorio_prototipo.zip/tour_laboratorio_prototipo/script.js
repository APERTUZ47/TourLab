(() => {
  const config = window.TOUR_SCENES;
  const state = {
    sceneId: null,
    scene: null,
    sound: false,
    targetTime: 0,
    currentHotspotId: null,
    previousSceneId: null,
    previousTime: 0,
    draggingTouchY: null,
    rafId: null
  };

  const els = {
    startScreen: document.getElementById("startScreen"),
    tourScreen: document.getElementById("tourScreen"),
    endScreen: document.getElementById("endScreen"),
    enterBtn: document.getElementById("enterBtn"),
    soundBtn: document.getElementById("soundBtn"),
    toggleSoundBtn: document.getElementById("toggleSoundBtn"),
    homeBtn: document.getElementById("homeBtn"),
    restartBtn: document.getElementById("restartBtn"),
    video: document.getElementById("tourVideo"),
    sceneLabel: document.getElementById("sceneLabel"),
    sceneInstruction: document.getElementById("sceneInstruction"),
    hotspotLayer: document.getElementById("hotspotLayer"),
    progressBar: document.getElementById("progressBar"),
    missingVideo: document.getElementById("missingVideo"),
    missingVideoName: document.getElementById("missingVideoName"),
    modal: document.getElementById("videoModal"),
    modalTitle: document.getElementById("modalTitle"),
    modalVideo: document.getElementById("modalVideo"),
    closeModalBtn: document.getElementById("closeModalBtn")
  };

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function showOnly(screen) {
    [els.startScreen, els.tourScreen, els.endScreen].forEach(el => el.classList.add("hidden"));
    screen.classList.remove("hidden");
  }

  function setSound(enabled) {
    state.sound = enabled;
    els.video.muted = !enabled;
    els.modalVideo.muted = !enabled;
    els.soundBtn.textContent = enabled ? "Sonido activado" : "Activar sonido";
    els.soundBtn.setAttribute("aria-pressed", String(enabled));
    els.toggleSoundBtn.textContent = enabled ? "Sonido: on" : "Sonido: off";
  }

  function videoUrl(fileName) {
    return `${config.videosPath}${fileName}`;
  }

  function loadScene(sceneId, options = {}) {
    const scene = config.scenes[sceneId];
    if (!scene) {
      console.warn(`No existe la escena: ${sceneId}`);
      return;
    }

    if (state.sceneId) {
      state.previousSceneId = state.sceneId;
      state.previousTime = state.targetTime;
    }

    state.sceneId = sceneId;
    state.scene = scene;
    state.targetTime = options.startAt ?? scene.startAt ?? 0;
    state.currentHotspotId = null;

    els.sceneLabel.textContent = scene.label;
    els.sceneInstruction.textContent = scene.instruction;
    els.hotspotLayer.innerHTML = "";
    els.progressBar.style.width = "0%";
    els.missingVideo.classList.add("hidden");

    els.video.pause();
    els.video.muted = !state.sound;
    els.video.src = videoUrl(scene.video);
    els.video.load();

    els.video.addEventListener("loadedmetadata", () => {
      const start = scene.startAt ?? 0;
      state.targetTime = clamp(state.targetTime, start, getSceneEnd());
      safeSeek(state.targetTime);
    }, { once: true });

    els.video.addEventListener("error", () => {
      els.missingVideoName.textContent = scene.video;
      els.missingVideo.classList.remove("hidden");
    }, { once: true });

    showOnly(els.tourScreen);
    startLoop();
  }

  function getSceneEnd() {
    const scene = state.scene;
    const metadataDuration = Number.isFinite(els.video.duration) ? els.video.duration : null;
    return scene.endAt ?? metadataDuration ?? 1;
  }

  function safeSeek(time) {
    try {
      els.video.currentTime = time;
    } catch (err) {
      // Algunos navegadores no permiten seek antes de tener metadata lista.
    }
  }

  function startLoop() {
    if (state.rafId) cancelAnimationFrame(state.rafId);

    const tick = () => {
      if (state.scene && !els.video.seeking && Number.isFinite(els.video.duration)) {
        const diff = state.targetTime - els.video.currentTime;
        if (Math.abs(diff) > 0.03) {
          safeSeek(els.video.currentTime + diff * 0.28);
        }
        updateProgress();
        updateHotspots();
      }
      state.rafId = requestAnimationFrame(tick);
    };

    tick();
  }

  function updateProgress() {
    const scene = state.scene;
    if (!scene) return;
    const start = scene.startAt ?? 0;
    const end = getSceneEnd();
    const pct = ((state.targetTime - start) / Math.max(0.1, end - start)) * 100;
    els.progressBar.style.width = `${clamp(pct, 0, 100)}%`;
  }

  function updateHotspots() {
    const scene = state.scene;
    if (!scene || !scene.hotspots) return;

    const active = scene.hotspots.find(hotspot => {
      const range = hotspot.window ?? 1.5;
      return Math.abs(state.targetTime - hotspot.time) <= range;
    });

    if (!active) {
      if (state.currentHotspotId) {
        state.currentHotspotId = null;
        els.hotspotLayer.innerHTML = "";
      }
      return;
    }

    if (state.currentHotspotId === active.id) return;
    state.currentHotspotId = active.id;
    renderHotspot(active);
  }

  function renderHotspot(hotspot) {
    const actions = hotspot.actions.map((action, index) => {
      const secondary = action.secondary ? " secondary" : "";
      return `<button class="hotspot-btn${secondary}" data-action-index="${index}">${action.label}</button>`;
    }).join("");

    els.hotspotLayer.innerHTML = `
      <article class="hotspot-card">
        <h2>${hotspot.title}</h2>
        <p>${hotspot.text}</p>
        <div class="hotspot-actions">${actions}</div>
      </article>
    `;

    els.hotspotLayer.querySelectorAll("[data-action-index]").forEach(button => {
      button.addEventListener("click", () => {
        const index = Number(button.dataset.actionIndex);
        handleAction(hotspot.actions[index]);
      });
    });
  }

  function handleAction(action) {
    if (!action) return;

    switch (action.type) {
      case "scene":
        loadScene(action.target);
        break;
      case "jump":
        state.targetTime = clamp(action.time, state.scene.startAt ?? 0, getSceneEnd());
        els.hotspotLayer.innerHTML = "";
        state.currentHotspotId = null;
        break;
      case "return": {
        const returnScene = state.scene.returnScene || state.previousSceneId || config.startScene;
        const returnTime = state.scene.returnTime ?? state.previousTime ?? 0;
        loadScene(returnScene, { startAt: returnTime });
        break;
      }
      case "modalVideo":
        openModal(action.video, action.title || "Video");
        break;
      case "message":
        alert(action.message);
        break;
      case "home":
        goHome();
        break;
      case "end":
        showOnly(els.endScreen);
        break;
      default:
        console.warn("Acción desconocida", action);
    }
  }

  function openModal(videoFile, title) {
    els.modalTitle.textContent = title;
    els.modalVideo.src = videoUrl(videoFile);
    els.modalVideo.muted = !state.sound;
    els.modal.classList.remove("hidden");
    els.modalVideo.play().catch(() => {});
  }

  function closeModal() {
    els.modalVideo.pause();
    els.modalVideo.removeAttribute("src");
    els.modalVideo.load();
    els.modal.classList.add("hidden");
  }

  function goHome() {
    closeModal();
    showOnly(els.startScreen);
    els.video.pause();
    els.video.removeAttribute("src");
    els.video.load();
    state.sceneId = null;
    state.scene = null;
    state.targetTime = 0;
    els.hotspotLayer.innerHTML = "";
  }

  function changeTimeByWheel(deltaY) {
    if (!state.scene || !els.tourScreen || !els.endScreen.classList.contains("hidden")) return;
    const direction = deltaY > 0 ? 1 : -1;
    const amount = Math.min(Math.abs(deltaY), 120) * (state.scene.scrollSensitivity ?? 0.018);
    state.targetTime = clamp(state.targetTime + direction * amount, state.scene.startAt ?? 0, getSceneEnd());
  }

  window.addEventListener("wheel", (event) => {
    if (els.tourScreen.classList.contains("hidden") || !els.modal.classList.contains("hidden")) return;
    event.preventDefault();
    changeTimeByWheel(event.deltaY);
  }, { passive: false });

  window.addEventListener("keydown", (event) => {
    if (els.tourScreen.classList.contains("hidden") || !state.scene) return;
    if (["ArrowDown", "PageDown", " "].includes(event.key)) {
      event.preventDefault();
      changeTimeByWheel(90);
    }
    if (["ArrowUp", "PageUp"].includes(event.key)) {
      event.preventDefault();
      changeTimeByWheel(-90);
    }
    if (event.key === "Escape") {
      if (!els.modal.classList.contains("hidden")) closeModal();
    }
  });

  window.addEventListener("touchstart", (event) => {
    state.draggingTouchY = event.touches[0].clientY;
  }, { passive: true });

  window.addEventListener("touchmove", (event) => {
    if (state.draggingTouchY === null || els.tourScreen.classList.contains("hidden") || !els.modal.classList.contains("hidden")) return;
    const currentY = event.touches[0].clientY;
    const delta = state.draggingTouchY - currentY;
    state.draggingTouchY = currentY;
    changeTimeByWheel(delta * 1.8);
  }, { passive: true });

  els.enterBtn.addEventListener("click", () => loadScene(config.startScene));
  els.soundBtn.addEventListener("click", () => setSound(!state.sound));
  els.toggleSoundBtn.addEventListener("click", () => setSound(!state.sound));
  els.homeBtn.addEventListener("click", goHome);
  els.restartBtn.addEventListener("click", goHome);
  els.closeModalBtn.addEventListener("click", closeModal);
  els.modal.addEventListener("click", event => {
    if (event.target === els.modal) closeModal();
  });

  setSound(false);
})();
